package com.mobiflow.android

import android.app.Application
import com.mobiflow.android.data.AppDatabase
import com.mobiflow.android.data.SeedImporter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MobiFlowApplication : Application() {
    val database by lazy { AppDatabase.create(this) }
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        appScope.launch { SeedImporter.importIfEmpty(this@MobiFlowApplication, database) }
    }
}
