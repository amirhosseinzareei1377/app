package com.mobiflow.android.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE isArchived=0 ORDER BY name")
    fun observeAll(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products ORDER BY name")
    suspend fun allNow(): List<ProductEntity>

    @Query("SELECT * FROM products WHERE id=:id")
    fun observe(id: String): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE id=:id")
    suspend fun get(id: String): ProductEntity?

    @Query("SELECT COUNT(*) FROM products")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<ProductEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(item: ProductEntity)

    @Query("UPDATE products SET stockQuantity=MAX(0,stockQuantity+:delta), updatedAt=:now WHERE id=:id")
    suspend fun changeStock(id: String, delta: Int, now: Long = System.currentTimeMillis())

    @Query("UPDATE products SET isArchived=1, updatedAt=:now WHERE id=:id")
    suspend fun archive(id: String, now: Long = System.currentTimeMillis())

    @Query("DELETE FROM products WHERE id=:id")
    suspend fun deletePermanently(id: String)

    @Query("DELETE FROM products")
    suspend fun deleteAll()
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY createdAt DESC") fun observeAll(): Flow<List<CustomerEntity>>
    @Query("SELECT * FROM customers ORDER BY createdAt DESC") suspend fun allNow(): List<CustomerEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(x: CustomerEntity)
    @Delete suspend fun delete(x: CustomerEntity)
    @Query("DELETE FROM customers") suspend fun deleteAll()
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC") fun observeAll(): Flow<List<ExpenseEntity>>
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC") suspend fun allNow(): List<ExpenseEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(x: ExpenseEntity)
    @Delete suspend fun delete(x: ExpenseEntity)
    @Query("DELETE FROM expenses") suspend fun deleteAll()
}

@Dao
interface ServiceDao {
    @Query("SELECT * FROM services ORDER BY createdAt DESC") fun observeAll(): Flow<List<ServiceEntity>>
    @Query("SELECT * FROM services ORDER BY createdAt DESC") suspend fun allNow(): List<ServiceEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(x: ServiceEntity)
    @Update suspend fun update(x: ServiceEntity)
    @Delete suspend fun delete(x: ServiceEntity)
    @Query("DELETE FROM services") suspend fun deleteAll()
}

@Dao
abstract class SaleDao {
    @Transaction
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    abstract fun observeAll(): Flow<List<SaleWithItems>>

    @Transaction
    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    abstract suspend fun allNow(): List<SaleWithItems>

    @Insert protected abstract suspend fun insertSale(sale: SaleEntity)
    @Insert protected abstract suspend fun insertItems(items: List<SaleItemEntity>)

    @Query("UPDATE products SET stockQuantity = stockQuantity - :quantity, updatedAt=:now WHERE id=:productId AND stockQuantity >= :quantity")
    protected abstract suspend fun decreaseStock(productId: String, quantity: Int, now: Long): Int

    @Transaction
    open suspend fun checkout(sale: SaleEntity, items: List<SaleItemEntity>) {
        require(items.isNotEmpty()) { "سبد فروش خالی است" }
        items.forEach {
            val changed = decreaseStock(it.productId, it.quantity, System.currentTimeMillis())
            require(changed == 1) { "موجودی ${it.productName} کافی نیست" }
        }
        insertSale(sale)
        insertItems(items)
    }

    @Query("DELETE FROM sale_items") abstract suspend fun deleteAllItems()
    @Query("DELETE FROM sales") abstract suspend fun deleteAllSales()

    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun restoreSales(items: List<SaleEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun restoreItems(items: List<SaleItemEntity>)
}
