package com.mobiflow.android.data
import android.content.Context
import org.json.JSONArray
object SeedImporter {
 suspend fun importIfEmpty(context:Context,db:AppDatabase):Int {
  if(db.products().count()>0) return 0
  val arr=JSONArray(context.assets.open("eways_products.json").bufferedReader().use{it.readText()})
  val list=buildList { for(i in 0 until arr.length()){ val x=arr.getJSONObject(i); add(ProductEntity(externalId=x.optString("productId"),name=x.optString("name"),barcode=x.optString("barcode"),purchasePrice=x.optDouble("lastPrice"),averageCost=x.optDouble("averageCost"),stockQuantity=0,historicalPurchasedQuantity=x.optDouble("qty").toInt(),notes="ورود از Eways • آخرین خرید: ${x.optString("lastDate")}")) } }
  return db.products().insertAll(list).count{it!=-1L}
 }
}
