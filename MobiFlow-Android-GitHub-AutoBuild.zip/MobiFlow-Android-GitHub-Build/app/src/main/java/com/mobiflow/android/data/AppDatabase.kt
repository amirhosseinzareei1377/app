package com.mobiflow.android.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ProductEntity::class, CustomerEntity::class, SaleEntity::class, SaleItemEntity::class, ExpenseEntity::class, ServiceEntity::class],
    version = 3,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun products(): ProductDao
    abstract fun customers(): CustomerDao
    abstract fun expenses(): ExpenseDao
    abstract fun services(): ServiceDao
    abstract fun sales(): SaleDao

    companion object {
        fun create(c: Context) = Room.databaseBuilder(c, AppDatabase::class.java, "mobiflow.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}
