package com.mobiflow.android.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mobiflow.android.ui.screens.*

private data class NavItem(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun MobiFlowApp() {
    val nav = rememberNavController()
    val items = listOf(
        NavItem("dashboard", "داشبورد", Icons.Default.Dashboard),
        NavItem("inventory", "انبار", Icons.Default.Inventory2),
        NavItem("sales", "فروش", Icons.Default.ShoppingCart),
        NavItem("customers", "مشتریان", Icons.Default.People),
        NavItem("more", "بیشتر", Icons.Default.MoreHoriz)
    )
    val current by nav.currentBackStackEntryAsState()
    val topRoute = current?.destination?.route
    val showBottom = topRoute in items.map { it.route }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF315DF4), background = Color(0xFFF7F8FC))) {
        Scaffold(bottomBar = {
            if (showBottom) NavigationBar {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = topRoute == item.route,
                        onClick = { nav.navigate(item.route) { launchSingleTop = true; restoreState = true; popUpTo("dashboard") { saveState = true } } },
                        icon = { Icon(item.icon, null) },
                        label = { Text(item.title) }
                    )
                }
            }
        }) { pad ->
            NavHost(nav, "dashboard", Modifier.padding(pad)) {
                composable("dashboard") { DashboardScreen(nav) }
                composable("inventory") { InventoryScreen(nav) }
                composable("product/{id}") { ProductDetailScreen(it.arguments?.getString("id") ?: return@composable, nav) }
                composable("sales") { SalesScreen() }
                composable("customers") { CustomersScreen() }
                composable("more") { MoreScreen(nav) }
                composable("services") { ServicesScreen(nav) }
                composable("expenses") { ExpensesScreen(nav) }
                composable("backup") { BackupScreen(nav) }
            }
        }
    }
}
