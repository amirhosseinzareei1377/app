package com.mobiflow.android.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "products", indices = [Index("externalId"), Index("barcode")])
data class ProductEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val externalId: String = "",
    val name: String,
    val brand: String = "",
    val model: String = "",
    val category: String = "لوازم جانبی",
    val barcode: String = "",
    val purchasePrice: Double = 0.0,
    val averageCost: Double = 0.0,
    val salePrice: Double = 0.0,
    val stockQuantity: Int = 0,
    val historicalPurchasedQuantity: Int = 0,
    val imageUri: String = "",
    val notes: String = "",
    val isArchived: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phone: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sales", indices = [Index("customerId")])
data class SaleEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val customerId: String? = null,
    val customerName: String = "فروش نقدی",
    val total: Double,
    val discount: Double = 0.0,
    val paymentMethod: String = "نقدی",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(entity = SaleEntity::class, parentColumns = ["id"], childColumns = ["saleId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = ProductEntity::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("saleId"), Index("productId")]
)
data class SaleItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val saleId: String,
    val productId: String,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val unitCost: Double = 0.0
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: String = "سایر",
    val amount: Double,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "services")
data class ServiceEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val customerName: String = "",
    val phone: String = "",
    val amount: Double = 0.0,
    val status: String = "در انتظار",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class SaleWithItems(
    @androidx.room.Embedded val sale: SaleEntity,
    @androidx.room.Relation(parentColumn = "id", entityColumn = "saleId") val items: List<SaleItemEntity>
)

data class CartLine(val product: ProductEntity, val quantity: Int)
