package com.mobiflow.android.data

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

object BackupManager {
    suspend fun export(context: Context, db: AppDatabase, uri: Uri) {
        val root = JSONObject().apply {
            put("format", "MobiFlow-Android-Backup")
            put("version", 2)
            put("createdAt", System.currentTimeMillis())
            put("products", JSONArray(db.products().allNow().map(::productJson)))
            put("customers", JSONArray(db.customers().allNow().map(::customerJson)))
            val sales = db.sales().allNow()
            put("sales", JSONArray(sales.map { saleJson(it.sale) }))
            put("saleItems", JSONArray(sales.flatMap { it.items }.map(::saleItemJson)))
            put("expenses", JSONArray(db.expenses().allNow().map(::expenseJson)))
            put("services", JSONArray(db.services().allNow().map(::serviceJson)))
        }
        context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(root.toString()) }
            ?: error("امکان نوشتن فایل پشتیبان وجود ندارد")
    }

    suspend fun restore(context: Context, db: AppDatabase, uri: Uri) {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: error("فایل پشتیبان خوانده نشد")
        val root = JSONObject(text)
        require(root.optString("format") == "MobiFlow-Android-Backup") { "فایل انتخاب‌شده پشتیبان معتبر موبی‌فلو نیست" }

        val products = root.getJSONArray("products").mapObjects(::productFromJson)
        val customers = root.optJSONArray("customers").mapObjects(::customerFromJson)
        val sales = root.optJSONArray("sales").mapObjects(::saleFromJson)
        val saleItems = root.optJSONArray("saleItems").mapObjects(::saleItemFromJson)
        val expenses = root.optJSONArray("expenses").mapObjects(::expenseFromJson)
        val services = root.optJSONArray("services").mapObjects(::serviceFromJson)

        db.withTransaction {
            db.sales().deleteAllItems()
            db.sales().deleteAllSales()
            db.expenses().deleteAll()
            db.services().deleteAll()
            db.customers().deleteAll()
            db.products().deleteAll()
            products.forEach { db.products().save(it) }
            customers.forEach { db.customers().insert(it) }
            db.sales().restoreSales(sales)
            db.sales().restoreItems(saleItems)
            expenses.forEach { db.expenses().insert(it) }
            services.forEach { db.services().insert(it) }
        }
    }

    private fun <T> JSONArray?.mapObjects(mapper: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        return List(length()) { mapper(getJSONObject(it)) }
    }

    private fun productJson(x: ProductEntity) = JSONObject().apply {
        put("id", x.id); put("externalId", x.externalId); put("name", x.name); put("brand", x.brand); put("model", x.model)
        put("category", x.category); put("barcode", x.barcode); put("purchasePrice", x.purchasePrice); put("averageCost", x.averageCost)
        put("salePrice", x.salePrice); put("stockQuantity", x.stockQuantity); put("historicalPurchasedQuantity", x.historicalPurchasedQuantity)
        put("imageUri", x.imageUri); put("notes", x.notes); put("isArchived", x.isArchived); put("updatedAt", x.updatedAt)
    }
    private fun productFromJson(x: JSONObject) = ProductEntity(
        id=x.getString("id"), externalId=x.optString("externalId"), name=x.getString("name"), brand=x.optString("brand"), model=x.optString("model"),
        category=x.optString("category","لوازم جانبی"), barcode=x.optString("barcode"), purchasePrice=x.optDouble("purchasePrice"), averageCost=x.optDouble("averageCost"),
        salePrice=x.optDouble("salePrice"), stockQuantity=x.optInt("stockQuantity"), historicalPurchasedQuantity=x.optInt("historicalPurchasedQuantity"),
        imageUri=x.optString("imageUri"), notes=x.optString("notes"), isArchived=x.optBoolean("isArchived"), updatedAt=x.optLong("updatedAt")
    )
    private fun customerJson(x: CustomerEntity)=JSONObject().apply{put("id",x.id);put("name",x.name);put("phone",x.phone);put("notes",x.notes);put("createdAt",x.createdAt)}
    private fun customerFromJson(x:JSONObject)=CustomerEntity(x.getString("id"),x.getString("name"),x.optString("phone"),x.optString("notes"),x.optLong("createdAt"))
    private fun saleJson(x:SaleEntity)=JSONObject().apply{put("id",x.id);put("customerId",x.customerId);put("customerName",x.customerName);put("total",x.total);put("discount",x.discount);put("paymentMethod",x.paymentMethod);put("notes",x.notes);put("createdAt",x.createdAt)}
    private fun saleFromJson(x:JSONObject)=SaleEntity(x.getString("id"),x.optString("customerId").takeIf{it.isNotBlank()},x.optString("customerName","فروش نقدی"),x.optDouble("total"),x.optDouble("discount"),x.optString("paymentMethod","نقدی"),x.optString("notes"),x.optLong("createdAt"))
    private fun saleItemJson(x:SaleItemEntity)=JSONObject().apply{put("id",x.id);put("saleId",x.saleId);put("productId",x.productId);put("productName",x.productName);put("quantity",x.quantity);put("unitPrice",x.unitPrice);put("unitCost",x.unitCost)}
    private fun saleItemFromJson(x:JSONObject)=SaleItemEntity(x.getString("id"),x.getString("saleId"),x.getString("productId"),x.getString("productName"),x.getInt("quantity"),x.getDouble("unitPrice"),x.optDouble("unitCost"))
    private fun expenseJson(x:ExpenseEntity)=JSONObject().apply{put("id",x.id);put("title",x.title);put("category",x.category);put("amount",x.amount);put("notes",x.notes);put("createdAt",x.createdAt)}
    private fun expenseFromJson(x:JSONObject)=ExpenseEntity(x.getString("id"),x.getString("title"),x.optString("category","سایر"),x.getDouble("amount"),x.optString("notes"),x.optLong("createdAt"))
    private fun serviceJson(x:ServiceEntity)=JSONObject().apply{put("id",x.id);put("title",x.title);put("customerName",x.customerName);put("phone",x.phone);put("amount",x.amount);put("status",x.status);put("notes",x.notes);put("createdAt",x.createdAt)}
    private fun serviceFromJson(x:JSONObject)=ServiceEntity(x.getString("id"),x.getString("title"),x.optString("customerName"),x.optString("phone"),x.optDouble("amount"),x.optString("status","در انتظار"),x.optString("notes"),x.optLong("createdAt"))
}
