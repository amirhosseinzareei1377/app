package com.mobiflow.android.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.mobiflow.android.MobiFlowApplication
import com.mobiflow.android.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
private fun db() = (LocalContext.current.applicationContext as MobiFlowApplication).database

private fun money(x: Double) = NumberFormat.getNumberInstance(Locale("fa", "IR")).format(x.toLong()) + " تومان"
private fun dateTime(x: Long) = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("fa", "IR")).format(Date(x))

@Composable
fun DashboardScreen(nav: NavController) {
    val d = db()
    val products by d.products().observeAll().collectAsStateWithLifecycle(emptyList())
    val sales by d.sales().observeAll().collectAsStateWithLifecycle(emptyList())
    val expenses by d.expenses().observeAll().collectAsStateWithLifecycle(emptyList())
    val todayStart = remember {
        java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val todaySales = sales.filter { it.sale.createdAt >= todayStart }.sumOf { it.sale.total }
    val todayExpense = expenses.filter { it.createdAt >= todayStart }.sumOf { it.amount }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("موبی‌فلو", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("مدیریت مستقل فروشگاه روی اندروید")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("کالا", products.size.toString(), Modifier.weight(1f))
            Stat("موجود", products.sumOf { it.stockQuantity }.toString(), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("فروش امروز", money(todaySales), Modifier.weight(1f))
            Stat("هزینه امروز", money(todayExpense), Modifier.weight(1f))
        }
        Stat("ارزش خرید موجودی", money(products.sumOf { it.averageCost * it.stockQuantity }), Modifier.fillMaxWidth())
        Button(onClick = { nav.navigate("sales") }, Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PointOfSale, null); Spacer(Modifier.width(8.dp)); Text("ثبت فروش جدید")
        }
        FilledTonalButton(onClick = { nav.navigate("inventory") }, Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Inventory2, null); Spacer(Modifier.width(8.dp)); Text("مدیریت انبار")
        }
    }
}

@Composable
private fun Stat(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp)) { Text(title); Text(value, fontWeight = FontWeight.Bold, maxLines = 2) } }
}

@Composable
fun InventoryScreen(nav: NavController) {
    val context = LocalContext.current
    val d = db()
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    val all by d.products().observeAll().collectAsStateWithLifecycle(emptyList())
    val list = remember(all, query) {
        if (query.isBlank()) all else all.filter { it.name.contains(query, true) || it.barcode.contains(query) || it.model.contains(query, true) }
    }
    LaunchedEffect(Unit) { SeedImporter.importIfEmpty(context, d) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("انبار", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            FilledTonalButton(onClick = { scope.launch { SeedImporter.importIfEmpty(context, d) } }) {
                Icon(Icons.Default.Download, null); Spacer(Modifier.width(4.dp)); Text("بانک Eways")
            }
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(vertical = 10.dp), placeholder = { Text("جست‌وجوی نام، مدل یا بارکد") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Text("${list.size} کالا • ${list.sumOf { it.stockQuantity }} عدد موجود", style = MaterialTheme.typography.labelMedium)
        LazyVerticalGrid(columns = GridCells.Adaptive(230.dp), contentPadding = PaddingValues(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { product ->
                ProductCard(product, { nav.navigate("product/${product.id}") }) { delta -> scope.launch { d.products().changeStock(product.id, delta) } }
            }
        }
    }
}

@Composable
private fun ProductCard(product: ProductEntity, open: () -> Unit, stock: (Int) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { open() }) {
        Column {
            Box(Modifier.fillMaxWidth().height(120.dp).background(MaterialTheme.colorScheme.primaryContainer)) {
                if (product.imageUri.isNotBlank()) AsyncImage(product.imageUri, null, Modifier.fillMaxSize())
                else Icon(Icons.Default.Inventory2, null, Modifier.size(54.dp).align(Alignment.Center), tint = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(product.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(product.model.ifBlank { product.externalId }, style = MaterialTheme.typography.labelSmall)
                Text(if (product.salePrice <= 0) "قیمت فروش ثبت نشده" else "قیمت فروش: ${money(product.salePrice)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { stock(-1) }, enabled = product.stockQuantity > 0) { Icon(Icons.Default.Remove, null) }
                    Text(product.stockQuantity.toString(), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { stock(1) }) { Icon(Icons.Default.Add, null) }
                    Spacer(Modifier.weight(1f))
                    Text(if (product.stockQuantity == 0) "ناموجود" else "موجود", color = if (product.stockQuantity == 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun ProductDetailScreen(id: String, nav: NavController) {
    val d = db(); val scope = rememberCoroutineScope(); val context = LocalContext.current
    val product by d.products().observe(id).collectAsStateWithLifecycle(null)
    var edit by remember(product) { mutableStateOf(product) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            edit = edit?.copy(imageUri = uri.toString())
        }
    }
    val p = product ?: return Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    if (edit == null) edit = p

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; Text("ویرایش کالا", style = MaterialTheme.typography.headlineSmall) }
        OutlinedTextField(edit!!.name, { edit = edit!!.copy(name = it) }, Modifier.fillMaxWidth(), label = { Text("نام کالا") })
        OutlinedTextField(edit!!.category, { edit = edit!!.copy(category = it) }, Modifier.fillMaxWidth(), label = { Text("دسته‌بندی") })
        OutlinedTextField(edit!!.barcode, { edit = edit!!.copy(barcode = it) }, Modifier.fillMaxWidth(), label = { Text("بارکد") }, trailingIcon = { Icon(Icons.Default.QrCodeScanner, null) })
        OutlinedTextField(edit!!.salePrice.takeIf { it > 0 }?.toLong()?.toString().orEmpty(), { edit = edit!!.copy(salePrice = it.toDoubleOrNull() ?: 0.0) }, Modifier.fillMaxWidth(), label = { Text("قیمت فروش") })
        OutlinedTextField(edit!!.purchasePrice.toLong().toString(), { edit = edit!!.copy(purchasePrice = it.toDoubleOrNull() ?: 0.0) }, Modifier.fillMaxWidth(), label = { Text("آخرین قیمت خرید") })
        OutlinedTextField(edit!!.notes, { edit = edit!!.copy(notes = it) }, Modifier.fillMaxWidth(), label = { Text("یادداشت") }, minLines = 2)
        Row { Button({ picker.launch(arrayOf("image/*")) }) { Icon(Icons.Default.Image, null); Text(" افزودن عکس") }; Spacer(Modifier.width(8.dp)); FilledTonalButton({ scope.launch { d.products().changeStock(id, 1) } }) { Text("+ موجودی") } }
        Button({ scope.launch { d.products().save(edit!!.copy(updatedAt = System.currentTimeMillis())); nav.popBackStack() } }, Modifier.fillMaxWidth()) { Text("ذخیره تغییرات") }
        TextButton({ scope.launch { d.products().archive(id); nav.popBackStack() } }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("انتقال به بایگانی") }
    }
}

@Composable
fun CustomersScreen() {
    val d = db(); val scope = rememberCoroutineScope(); val customers by d.customers().observeAll().collectAsStateWithLifecycle(emptyList())
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("مشتریان", style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.weight(1f)); FloatingActionButton({ show = true }) { Icon(Icons.Default.PersonAdd, null) } }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 12.dp)) {
            items(customers, key = { it.id }) { customer ->
                ListItem(headlineContent = { Text(customer.name) }, supportingContent = { Text(customer.phone.ifBlank { "بدون شماره تماس" }) }, trailingContent = { IconButton({ scope.launch { d.customers().delete(customer) } }) { Icon(Icons.Default.Delete, null) } })
                HorizontalDivider()
            }
        }
    }
    if (show) CustomerDialog(onDismiss = { show = false }) { scope.launch { d.customers().insert(it) }; show = false }
}

@Composable
private fun CustomerDialog(onDismiss: () -> Unit, save: (CustomerEntity) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("مشتری جدید") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text("نام") }); OutlinedTextField(phone, { phone = it }, label = { Text("شماره تماس") }); OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") })
    } }, confirmButton = { Button({ if (name.isNotBlank()) save(CustomerEntity(name = name, phone = phone, notes = notes)) }, enabled = name.isNotBlank()) { Text("ثبت") } }, dismissButton = { TextButton(onDismiss) { Text("انصراف") } })
}

@Composable
fun SalesScreen() {
    val d = db(); val scope = rememberCoroutineScope(); val context = LocalContext.current
    val products by d.products().observeAll().collectAsStateWithLifecycle(emptyList())
    val history by d.sales().observeAll().collectAsStateWithLifecycle(emptyList())
    var query by remember { mutableStateOf("") }; var cart by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }; var tab by remember { mutableIntStateOf(0) }; var discountText by remember { mutableStateOf("") }
    val available = remember(products, query) { products.filter { it.stockQuantity > 0 && (query.isBlank() || it.name.contains(query, true) || it.barcode.contains(query)) } }
    val cartLines = remember(cart, products) { cart.mapNotNull { (id, qty) -> products.firstOrNull { it.id == id }?.let { CartLine(it, qty) } } }
    val subtotal = cartLines.sumOf { it.product.salePrice * it.quantity }
    val discount = discountText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val total = (subtotal - discount).coerceAtLeast(0.0)

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("فروش", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        TabRow(tab) { Tab(tab == 0, { tab = 0 }, text = { Text("صندوق") }); Tab(tab == 1, { tab = 1 }, text = { Text("تاریخچه") }) }
        if (tab == 0) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(top = 10.dp), placeholder = { Text("جست‌وجوی کالا") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
            LazyColumn(Modifier.weight(1f)) {
                items(available, key = { it.id }) { p ->
                    ListItem(headlineContent = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) }, supportingContent = { Text("موجودی ${p.stockQuantity} • ${if (p.salePrice > 0) money(p.salePrice) else "قیمت فروش ندارد"}") }, trailingContent = {
                        IconButton(onClick = { if (p.salePrice > 0) { val old = cart[p.id] ?: 0; if (old < p.stockQuantity) cart = cart + (p.id to old + 1) } }, enabled = p.salePrice > 0) { Icon(Icons.Default.AddShoppingCart, null) }
                    })
                    HorizontalDivider()
                }
            }
            if (cartLines.isNotEmpty()) {
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("سبد فروش", fontWeight = FontWeight.Bold)
                    cartLines.forEach { line -> Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(line.product.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        IconButton({ val n = line.quantity - 1; cart = if (n <= 0) cart - line.product.id else cart + (line.product.id to n) }) { Icon(Icons.Default.Remove, null) }
                        Text(line.quantity.toString()); IconButton({ if (line.quantity < line.product.stockQuantity) cart = cart + (line.product.id to line.quantity + 1) }) { Icon(Icons.Default.Add, null) }
                    } }
                    OutlinedTextField(discountText, { discountText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("تخفیف") }, singleLine = true)
                    Text("جمع نهایی: ${money(total)}", fontWeight = FontWeight.Bold)
                    Button(onClick = {
                        scope.launch {
                            runCatching {
                                val saleId = UUID.randomUUID().toString()
                                val sale = SaleEntity(id = saleId, total = total, discount = discount)
                                val items = cartLines.map { SaleItemEntity(saleId = saleId, productId = it.product.id, productName = it.product.name, quantity = it.quantity, unitPrice = it.product.salePrice, unitCost = it.product.averageCost) }
                                d.sales().checkout(sale, items)
                            }.onSuccess { cart = emptyMap(); discountText = ""; Toast.makeText(context, "فروش ثبت شد", Toast.LENGTH_SHORT).show() }
                                .onFailure { Toast.makeText(context, it.message ?: "خطا در ثبت فروش", Toast.LENGTH_LONG).show() }
                        }
                    }, Modifier.fillMaxWidth()) { Text("ثبت قطعی فروش") }
                } }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 10.dp)) {
                items(history, key = { it.sale.id }) { row ->
                    ListItem(headlineContent = { Text(money(row.sale.total), fontWeight = FontWeight.Bold) }, supportingContent = { Text("${row.items.size} قلم • ${dateTime(row.sale.createdAt)}") }, trailingContent = { Text(row.sale.paymentMethod) })
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun ExpensesScreen(nav: NavController) {
    val d = db(); val scope = rememberCoroutineScope(); val items by d.expenses().observeAll().collectAsStateWithLifecycle(emptyList()); var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; Text("هزینه‌ها", style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.weight(1f)); FloatingActionButton({ show = true }) { Icon(Icons.Default.Add, null) } }
        Text("جمع کل: ${money(items.sumOf { it.amount })}", Modifier.padding(vertical = 8.dp), fontWeight = FontWeight.Bold)
        LazyColumn { items(items, key = { it.id }) { x -> ListItem(headlineContent = { Text(x.title) }, supportingContent = { Text("${x.category} • ${dateTime(x.createdAt)}") }, trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { Text(money(x.amount)); IconButton({ scope.launch { d.expenses().delete(x) } }) { Icon(Icons.Default.Delete, null) } } }); HorizontalDivider() } }
    }
    if (show) ExpenseDialog({ show = false }) { scope.launch { d.expenses().insert(it) }; show = false }
}

@Composable
private fun ExpenseDialog(dismiss: () -> Unit, save: (ExpenseEntity) -> Unit) {
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("سایر") }
    AlertDialog(onDismissRequest = dismiss, title = { Text("هزینه جدید") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(title, { title = it }, label = { Text("عنوان") }); OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("مبلغ") }); OutlinedTextField(category, { category = it }, label = { Text("دسته") }) } }, confirmButton = { Button({ save(ExpenseEntity(title = title, amount = amount.toDoubleOrNull() ?: 0.0, category = category)) }, enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) { Text("ثبت") } }, dismissButton = { TextButton(dismiss) { Text("انصراف") } })
}

@Composable
fun ServicesScreen(nav: NavController) {
    val d = db(); val scope = rememberCoroutineScope(); val items by d.services().observeAll().collectAsStateWithLifecycle(emptyList()); var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; Text("خدمات", style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.weight(1f)); FloatingActionButton({ show = true }) { Icon(Icons.Default.Add, null) } }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp)) { items(items, key = { it.id }) { x ->
            ListItem(headlineContent = { Text(x.title) }, supportingContent = { Text("${x.customerName.ifBlank { "بدون مشتری" }} • ${x.status}") }, trailingContent = { Row(verticalAlignment = Alignment.CenterVertically) { Text(money(x.amount)); IconButton({ scope.launch { d.services().delete(x) } }) { Icon(Icons.Default.Delete, null) } } })
            HorizontalDivider()
        } }
    }
    if (show) ServiceDialog({ show = false }) { scope.launch { d.services().insert(it) }; show = false }
}

@Composable
private fun ServiceDialog(dismiss: () -> Unit, save: (ServiceEntity) -> Unit) {
    var title by remember { mutableStateOf("") }; var customer by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = dismiss, title = { Text("خدمت جدید") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(title, { title = it }, label = { Text("عنوان خدمت") }); OutlinedTextField(customer, { customer = it }, label = { Text("نام مشتری") }); OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("مبلغ") }) } }, confirmButton = { Button({ save(ServiceEntity(title = title, customerName = customer, amount = amount.toDoubleOrNull() ?: 0.0)) }, enabled = title.isNotBlank()) { Text("ثبت") } }, dismissButton = { TextButton(dismiss) { Text("انصراف") } })
}

@Composable
fun BackupScreen(nav: NavController) {
    val context = LocalContext.current; val d = db(); val scope = rememberCoroutineScope(); var message by remember { mutableStateOf("") }
    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if (uri != null) scope.launch { runCatching { BackupManager.export(context, d, uri) }.onSuccess { message = "پشتیبان با موفقیت ذخیره شد" }.onFailure { message = it.message ?: "خطا در پشتیبان‌گیری" } } }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) scope.launch { runCatching { BackupManager.restore(context, d, uri) }.onSuccess { message = "بازیابی با موفقیت انجام شد" }.onFailure { message = it.message ?: "خطا در بازیابی" } } }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }; Text("پشتیبان‌گیری", style = MaterialTheme.typography.headlineSmall) }
        Text("این فایل شامل کالاها، موجودی، مشتریان، فروش‌ها، هزینه‌ها و خدمات است.")
        Button({ create.launch("mobiflow-backup-${System.currentTimeMillis()}.json") }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("ساخت فایل پشتیبان") }
        OutlinedButton({ open.launch(arrayOf("application/json", "text/plain")) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("بازیابی از فایل") }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        Text("توجه: بازیابی، اطلاعات فعلی برنامه را با محتوای فایل جایگزین می‌کند.", color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun MoreScreen(nav: NavController) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("بیشتر", style = MaterialTheme.typography.headlineSmall)
        ListItem(modifier = Modifier.clickable { nav.navigate("services") }, headlineContent = { Text("خدمات") }, supportingContent = { Text("ثبت و پیگیری خدمات فروشگاه") }, leadingContent = { Icon(Icons.Default.Build, null) }, trailingContent = { Icon(Icons.Default.ChevronLeft, null) })
        ListItem(modifier = Modifier.clickable { nav.navigate("expenses") }, headlineContent = { Text("هزینه‌ها") }, supportingContent = { Text("ثبت مخارج و هزینه‌های روزانه") }, leadingContent = { Icon(Icons.Default.Payments, null) }, trailingContent = { Icon(Icons.Default.ChevronLeft, null) })
        ListItem(modifier = Modifier.clickable { nav.navigate("backup") }, headlineContent = { Text("پشتیبان‌گیری محلی") }, supportingContent = { Text("خروجی و بازیابی همه اطلاعات") }, leadingContent = { Icon(Icons.Default.Backup, null) }, trailingContent = { Icon(Icons.Default.ChevronLeft, null) })
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("نسخه مستقل اندروید؛ هیچ داده‌ای با iOS همگام نمی‌شود.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
